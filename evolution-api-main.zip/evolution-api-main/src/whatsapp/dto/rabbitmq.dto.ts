export class RabbitmqDto {
  enabled: boolean;
  events?: string[];
}
